from flask import Flask, url_for, request, render_template, session
from flask_sqlalchemy import SQLAlchemy

#render_template loads the html files plus anything in the fancy {} brackets
#session saves user information in the form of a variable that's saved for as long as the user is logged in (for example: I could put a user's username in a variable so it's always accessible to the app code)
#request gets POST information from a form
#url_for generates a link the code can follow (works inside an html file too)

#SQL_alchemy creates an instance with a database file inside

app = Flask(__name__)
app.secret_key = 'SuperBowlFitness'

#database creation ---------------
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

db = SQLAlchemy(app)

class User(db.Model):
    #__tablename__ = 'Userinfo'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(25), unique=True, nullable=False)
    email = db.Column(db.String(50), unique=True, nullable=False)
    #PASSWORD WILL BE HASHED IF WE CONTINUE USING THIS FLASK FILE
    password = db.Column(db.String(250), unique=False, nullable=False)
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    age = db.Column(db.String(10), unique=False, nullable=False)
    goal = db.Column(db.String(10), unique=False, nullable=False)
    workout_num = db.Column(db.String(10), unique=False, nullable=False)
    calories_burned = db.Column(db.String(10), unique=False, nullable=False)

#vv
def __repr__(self):
    return f'<User {self.username}>'
#^^

with app.app_context():
    db.create_all()
#---------------------------------



@app.route('/')
def home():
    print("reached base.html")
    return render_template('base.html')


#temporary route to each html file, I may delete some of these after reviewing the website code and its needs.

@app.route('/dashboard')
def dashboard():
    print("dashboard routing is working")
    if "user" in session:
        return render_template('dashboard.html', workouts=session["workouts"], calories=session["calories"])
    else:
        render_template('login.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/log')
def og():
    return render_template('log.html')

@app.route('/login',  methods=['POST', 'GET'])
def login():

    if request.method == 'POST':
        username = request.form['name']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()

        if user and user.password:

            session["user"] = username

            session["workouts"] = user.workout_num
            session["calories"] = user.calories_burned
            session["age"] = user.age
            session["email"] = user.email
            session["goal"] = user.goal

            return render_template('dashboard.html', workouts=session["workouts"], calories=session["calories"])
        else:
            print("try again")

    return render_template('login.html')

#signup, the methods include post because it handles form data
@app.route('/signup', methods=['POST', 'GET'])
def signup():

    #the request.method will equal POST when the form is submitted, otherwise the website is just trying to render the template
    if request.method == 'POST':
        username = request.form['name']
        password = request.form['password']
        #the database didn't create the email column correctly, but it's a tad too late to fix that now
        email = request.form['email']
        age = request.form['age']
        goal = request.form['goal']

        #this code was copied from an old project, I'll modify it if we need this website later, but since we're likely going edit this code heavily once integrated with Swift, we might not even end up needing this.  ...........
        unique_user = User(username=username, email=email, password=password, workout_num=0, calories_burned=0, age=age, goal=goal)
        db.session.add(unique_user)

        try:
            db.session.commit()
            print("user added successfully")
            #log the user in automatically upon signing up
            #this code here should also probably be a function if we continue using this file ********************
            session["user"] = username
            #session["pass"] = password #commenting this out because having the password in session may be a security risk
            

            #move these three below user.query when moved to /login
            session["age"] = age
            session["email"] = email
            session["goal"] = goal

            user = User.query.filter_by(username=username).first()
            session["workouts"] = user.workout_num
            session["calories"] = user.calories_burned
            print(session["workouts"])
            #when the dashboard is rendered after 
            return render_template('dashboard.html', workouts=session["workouts"], calories=session["calories"])
            #*****************************************************************************************************
            

        except Exception as e:
            db.session.rollback()
            print("Commit failed. Error:" + str(e))
            return render_template('signup.html', error="That username or email has already been taken.")
        #........................................................................................................................


    return render_template('signup.html')

@app.route('/log')
def log():
    return render_template('log.html')

@app.route('/workout')
def workout():
    return render_template('workout.html')

@app.route('/profile')
def profile():

    if "user" in session:


        return render_template('profile.html', username=session["user"], email=session["email"], age=session["age"], goal=session["goal"])
    
    else:
        return render_template('login.html')
#------------------------------------------------------------

if __name__ == '__main__':
    app.run(debug=True)